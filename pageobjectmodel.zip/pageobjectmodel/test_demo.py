import pytest


@pytest.fixture()
def setup():
    print("this is fixture")
    yield
    print("this is teardown")

@pytest.mark.smoke
def test_first(setup):
    print("this is first pytest program")
    assert 2 == 2


@pytest.mark.smoke
def test_demo_example1(setup):
    print("this is first pytest program2")


@pytest.mark.sanity
def test_demo_example3(setup):
    print("this is first pytest program3")
