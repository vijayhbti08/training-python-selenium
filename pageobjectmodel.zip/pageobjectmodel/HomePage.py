from selenium.webdriver.common.by import By


class HomePage():

    def __init__(self, driver):
        self.driver = driver

    user_name = (By.ID, "user-name")
    password = (By.ID, "password")
    login_button = (By.ID, "login-button")

    def user_name_locator(self):
        return self.driver.find_element(*self.user_name)

    def password_locator(self):
        return self.driver.find_element(*self.password)

    def login_locator(self):
        return self.driver.find_element(*self.login_button)

    def login_sauce_lab(self, username, password):
        self.user_name_locator().send_keys(username)
        self.password_locator().send_keys(password)
        self.login_locator().click()