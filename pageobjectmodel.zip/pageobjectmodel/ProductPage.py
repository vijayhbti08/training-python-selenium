from selenium.webdriver.common.by import By


class ProductPage:
    sauce_lab_backpack_button = (By.ID, "add-to-cart-sauce-labs-backpack")
    sauce_lab_bike_light_button = (By.ID, "add-to-cart-sauce-labs-bike-light")
    shopping_cart = (By.CLASS_NAME, "shopping_cart_badge")

    def __init__(self, driver):
        self.driver = driver

    def backpack_element(self):
        return self.driver.find_element(*self.sauce_lab_backpack_button)

    def bike_light_element(self):
        return self.driver.find_element(*self.sauce_lab_bike_light_button)

    def shopping_cart_element(self):
        return self.driver.find_element(*self.shopping_cart)

    def select_backpack_option(self):
        self.backpack_element().click()

    def select_bike_light_option(self):
        self.bike_light_element().click()

    def verify_cart_item_count(self):
        assert self.shopping_cart_element().text == '1'
