from selenium import webdriver

from HomePage import HomePage
from ProductPage import ProductPage

driver = webdriver.Chrome()
driver.get("https://www.saucedemo.com/")
driver.implicitly_wait(20)
driver.maximize_window()

homepage = HomePage(driver)
homepage.login_sauce_lab("standard_user", "secret_sauce")
product_page = ProductPage(driver)
product_page.select_backpack_option()
product_page.verify_cart_item_count()


