import pytest
from selenium.webdriver.common.by import By

from pageobjects.LoginPage import LoginPage
from pageobjects.ProductPage import ProductPage
from utilities.BaseClass import BaseClass
from testdata.testdata import *


class TestLogin(BaseClass):
    @pytest.mark.sanity
    def test_login(self):
        self.log = self.get_Logger()

        self.driver.get("https://www.saucedemo.com/")

        loginpage = LoginPage(self.driver)
        loginpage.login_sauce_lab(USERNAME, PASSWORD)
        self.log.info("Login is successfully doe for saucelab")
        productpage = ProductPage(self.driver)
        productpage.select_bag_pack_option()
        self.log.info("Selected bag pack option successfully")
        productpage.verify_shopping_cart_count()
        self.log.info("Verified product count")

    def test_demo(self):
        assert 2 == 3
