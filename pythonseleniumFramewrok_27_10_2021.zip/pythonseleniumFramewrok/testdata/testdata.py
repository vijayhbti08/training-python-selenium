USERNAME = "standard_user"
PASSWORD = "secret_sauce"