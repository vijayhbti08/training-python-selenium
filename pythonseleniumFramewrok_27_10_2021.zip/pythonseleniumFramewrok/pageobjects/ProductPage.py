from selenium.webdriver.common.by import By


class ProductPage:

    def __init__(self, driver):
        self.driver = driver

    bagpack = (By.ID, "add-to-cart-sauce-labs-backpack")
    bikelight = (By.ID, "add-to-cart-sauce-labs-bike-light")
    shopping_cart = (By.CLASS_NAME, "shopping_cart_badge")

    def bag_pack_element(self):
        return self.driver.find_element(*ProductPage.bagpack)

    def bike_light_element(self):
        return self.driver.find_element(*ProductPage.bikelight)

    def shopping_cart_element(self):
        return self.driver.find_element(*ProductPage.shopping_cart)

    def select_bag_pack_option(self):
        self.bag_pack_element().click()

    def select_bike_light_option(self):
        self.bike_light_element().click()

    def verify_shopping_cart_count(self):
        assert self.shopping_cart_element().text == '1'
