import pytest


def test_demo1(setup):
    print("Conf test example")


def test_dataLoad(dataLoad):
    print("1st test Data:" + dataLoad[0])
    print("2nd test Data:" + dataLoad[1])
    print("3rd test Data:" + dataLoad[2])


def test_multipledata(mutipletestdata):
    print(mutipletestdata[0] + " " + mutipletestdata[1])
