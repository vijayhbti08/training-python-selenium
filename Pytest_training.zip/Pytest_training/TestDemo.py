import pytest


@pytest.mark.usefixtures("setupclasslevel")
class TestDemo:

    def test_demo1(self):
        print("Class test demo1")

    def test_demo2(self):
        print("Class test demo2")

    def test_demo3(self):
        print("Class test demo3")

    def test_demo4(self):
        print("Class test demo4")
