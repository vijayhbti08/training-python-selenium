import pytest

import logging
import inspect


@pytest.fixture()
def setup():
    print("this is fixture")
    yield
    print("this is teardown")


@pytest.mark.smoke
def test_first(setup):
    print("this is first pytest program")
    assert 2 == 2


@pytest.mark.smoke
def test_demo_example1(setup, dataLoad):
    print("this is first pytest program2")
    print(dataLoad[0])


@pytest.fixture()
def dataLoad():
    return ["training", "session", ]


@pytest.mark.sanity
def test_demo_example3(dataLoad1):
    print("this is first pytest program3")
    print(dataLoad1[0] + " " + dataLoad1[1])


@pytest.fixture(params=[("Chrome", "User1"), ("Firefox", "user2")])
def dataLoad1(request):
    return request.param


def test_testdata():
    print(testdata.username)
    print(testdata.password)
    print(testdata.keycode)


def test_logger():
    loggerName = inspect.stack()[1][3]
    logger = logging.getLogger(loggerName)
    filehandler = logging.FileHandler("../testlog.log")
    formatter = logging.Formatter("%(asctime)s :%(levelname)s :%(name)s: %(message)s")
    filehandler.setFormatter(formatter)
    logger.addHandler(filehandler)
    logger.setLevel(logging.DEBUG)
    logger.info("This is first")
