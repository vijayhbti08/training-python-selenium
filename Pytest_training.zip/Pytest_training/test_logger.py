import logging


def test_logging1():
    logger = logging.getLogger(__name__)
    filehandler = logging.FileHandler("test.log")
    formatter = logging.Formatter("%(asctime)s: %(levelname)s :%(name)s : %(message)s")
    filehandler.setFormatter(formatter)
    logger.addHandler(filehandler)
    logger.setLevel(level=logging.DEBUG)
    logger.info("This is info level")
    logger.warning("This is warning level")
    logger.critical("This is critical level")
