import pytest


@pytest.fixture()
def setup():
    print("this is fixture")
    yield
    print("this is teardown")


@pytest.fixture(scope="class")  # function  class  module session
def setupclasslevel():
    print("this is fixture before execution of class")
    yield
    print("this is teardown after execution of class")


@pytest.fixture()
def dataLoad():
    return ["Rishabh", "Mahesh", "Chiranth"]


@pytest.fixture(params=[("Chrome", "test1"), ("Firefox", "test2"), ("IE", "test3")])
def mutipletestdata(request):
    return request.param
