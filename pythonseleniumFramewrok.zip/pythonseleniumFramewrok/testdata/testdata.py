USERNAME = "standard_user"
PASSWORD = "password"